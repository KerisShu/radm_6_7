/*
 * File      : stm32f20x_40x_spi.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2009 RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2012-01-01     aozima       first implementation.
 * 2018-03-30     misonyo      porting to gd32f30x
 * 2021-06-01     keris
 *  这里是文件管理系统所需内存挂载到spi *#*#*#*#
 */
#include <board.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "spi_flash.h"
#include "spi_flash_sfud.h"


/*  DEVICE1 */

#define SPI_BUS_NAME                "spi0"
#define SPI_DEVICE_NAME             "spi01"
#define SPI_FLASH_DEVICE_NAME       "gd25q"
#define GD25Q_SPI_CS_PIN             2          //PE3，在 drv_gpio.c 文件 pin_index pins[]中查到 PE3 编号为 2

/* end of DEVICE1 */


/* DEVICE2 */

#define SPI_BUS_NAME2                  "spi1"
#define SPI_DEVICE_NAME_1              "spi02"   //test
#define SPI_LCD_DEVICE_NAME            "lcd_tft"
#define LCD_SPI_CS_PIN                 124        //PG9，在 drv_gpio.c 文件 pin_index pins[]中查到 PG9 编号为 124

/* end of DEVICE2 */


static int rt_hw_gd25q40_init(void)
{

    rt_err_t res;
    static struct rt_spi_device spi_dev_gd25q;           /* SPI设备对象 */
    static rt_base_t gd25q_cs_pin;                       /* SPI设备CS片选引脚 */
    gd25q_cs_pin = GD25Q_SPI_CS_PIN;
    rt_pin_mode(GD25Q_SPI_CS_PIN, GPIO_MODE_OUT_PP);
    res = rt_spi_bus_attach_device(&spi_dev_gd25q, SPI_DEVICE_NAME, SPI_BUS_NAME, (void*)gd25q_cs_pin);

    if (res != RT_EOK)
    {
        rt_kprintf("rt_spi_bus_attach_device() run failed!\n");
        return res;
    }

    return RT_EOK;
}
INIT_DEVICE_EXPORT(rt_hw_gd25q40_init);


static int rt_hw_lcd_init(void)
{
    rt_err_t res1;
    static struct rt_spi_device spi_dev_lcd;  //test
    static rt_base_t lcd_cs_pin ;
    lcd_cs_pin = LCD_SPI_CS_PIN;   //test
    rt_pin_mode(LCD_SPI_CS_PIN, GPIO_MODE_OUT_PP);
    res1 = rt_spi_bus_attach_device(&spi_dev_lcd, SPI_DEVICE_NAME, SPI_BUS_NAME2, (void*)lcd_cs_pin);   //test

    if (res1 != RT_EOK)
    {
        rt_kprintf("rt_spi_bus_attach_device() run failed!\n");
        return res1;
    }

    return RT_EOK;
}
INIT_DEVICE_EXPORT(rt_hw_lcd_init);


static int rt_hw_spi_flash_with_sfud_init(void)
{
    if (RT_NULL == rt_sfud_flash_probe(SPI_FLASH_DEVICE_NAME, SPI_DEVICE_NAME))
    {
        return RT_ERROR;
    }

    return RT_EOK;
}
INIT_COMPONENT_EXPORT(rt_hw_spi_flash_with_sfud_init);


static int rt_hw_spi_lcd_with_sfud_init(void)
{
    if (RT_NULL == rt_sfud_flash_probe(SPI_LCD_DEVICE_NAME, SPI_DEVICE_NAME))
    {
        return RT_ERROR;
    }

    return RT_EOK;
}
INIT_COMPONENT_EXPORT(rt_hw_spi_lcd_with_sfud_init);


#ifdef RT_USING_DFS
#include <dfs_fs.h>

static int mnt_init(void)
{
    mkfs("elm",SPI_FLASH_DEVICE_NAME);   // 挂载前需格式化，丢了这句会出现bad file


    if (dfs_mount(SPI_FLASH_DEVICE_NAME, "/", "elm", 0, 0) == 0)
    {
        rt_kprintf("spi flash gd25q1 mount success !\n");
    }
    else
    {
        rt_kprintf("spi flash gd25q1 mount failed!\n");
    }

    mkfs("elm",SPI_LCD_DEVICE_NAME);   // 挂载前需格式化   //test
    if (dfs_mount(SPI_LCD_DEVICE_NAME, "/", "nfs", 0, 0) == 0)
    {
        rt_kprintf("spi lcd_tft mount success !\n");
    }
    else
    {
        rt_kprintf("spi flash mount failed!\n");
    }


    return 0;

}

INIT_ENV_EXPORT(mnt_init);
//MSH_CMD_EXPORT(mnt_init, mount spi flash to file system);// 挂载spi到文件系统
#endif
