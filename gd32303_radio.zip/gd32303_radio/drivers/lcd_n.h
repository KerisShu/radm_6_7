/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-05-27     shangwang7       the first version
 */

/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-05-27     shangwang7       the first version
 */

#ifndef __LCD_N_H
#define __LCD_N_H 
              
#include "gd32f30x.h"

#include "gd32f303e_eval.h"
#include <stdio.h>
#include "systick.h"
#define uchar      unsigned char
#define uint       unsigned int
 
#define A0_0  GPIO_BOP(GPIOC)=GPIO_PIN_2
#define A0_1  GPIO_BC(GPIOC)=GPIO_PIN_2
 
#define WR_0  GPIO_BOP(GPIOC)=GPIO_PIN_3
#define WR_1  GPIO_BC(GPIOC)=GPIO_PIN_3
 
#define RD_0  GPIO_BOP(GPIOC)=GPIO_PIN_4
#define RD_1  GPIO_BC(GPIOC)=GPIO_PIN_4
 
#define CS_0  GPIO_BOP(GPIOC)=GPIO_PIN_5
#define CS_1  GPIO_BC(GPIOC)=GPIO_PIN_5
 
#define BUSY  gpio_input_bit_get(GPIOC,GPIO_PIN_6)
 
#define DataOUT GPIO_OCTL(GPIOB)
 
#define DataIN  GPIO_ISTAT(GPIOB)
 
 
/*--------------------------------------------------------------*/
//???????????
 
#define                SystemSet        0x40
#define                SleepIn                0x53
#define                DispOn                0x59
#define                DispOff                0x58
#define                Scroll                0x44
#define                Csrform                0x5d
#define                CgramAdr        0x50
#define                CsrDirR                0x4c
#define                CsrDirL                0x4d
#define                CsrDirU                0x4e
#define                CsrDirD                0x4f        
#define                HdotSet                0x5a
#define                Ovlay                0x5b
#define                CsrW                0x46
#define                CsrR                0x47
#define                mWrite                0x42        
#define                mRead                0x43
 
void LCD_PinInit(void);
void chk_busy(void);
void send_cmd(uchar cmd);
void send_dat(uchar dat);
 
void Delay_Nms(uint n);
void Delay_Nus(uint n);
#define LCD_SCROLL                0x44
 
void LcdClear(void);
//------------flag  0??  1??-----------------------------------------------
void LcdHZ(unsigned char x, unsigned int y,unsigned char *pdata,unsigned char flag); 
void LcdChar(unsigned char x, unsigned char y, unsigned char *pdata, unsigned char flag);
//-----------flag = 0 ??(?), bf=1 ??(?), bf=2 ????(??)-----------
void LcdPoint( unsigned int x, unsigned int y, unsigned char flag); 
//-----------flag = 0 ??(?), bf=1 ??(?), bf=2 ????(??)-----------
void LcdLine(unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1, unsigned char flag);
void LcdInit(void); 
void  LcdCsrW ( unsigned char x, unsigned char y);
void Delay_ns(); 
 
 
#endif


