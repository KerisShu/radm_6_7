/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-06-01     Keris       the first version
 */
#ifndef DRIVERS_MYPINS_H_
#define DRIVERS_MYPINS_H_

#include <drivers/pin.h>

/* definitions of pins */
#define     LED_WARNING_PIN         10
#define     BUZZER_PIN              56
#define     KEY_ON_OFF_PIN          34
#define     KEY_SIG_PIN             15
#define     KEY_DIRECTION_PIN       14
#define     KEY_BACKLIGHT_PIN       7
/* end of definitions of pins */

#endif /* DRIVERS_MYPINS_H_ */
