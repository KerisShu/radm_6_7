/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-05-27     shangwang7       the first version
 */

// ���� ͨ��EXMC ���� LCD

#include <drivers/pin.h>
#include <rtdef.h>
//#include <rtthread.h>

/* definitions of EXMC pins */

#define EXMC_NE1_PIN    124  //PG9
#define EXMC_NWE_PIN    119  //PD5
#define EXMC_NOE_PIN    118  //PD4
#define EXMC_A23_PIN    1    //PE2
#define EXMC_D15_PIN    79   //PD10
#define EXMC_D14_PIN    78   //PD9
#define EXMC_D13_PIN    77   //PD8
#define EXMC_D12_PIN    68   //PE15
#define EXMC_D11_PIN    67   //PE14
#define EXMC_D10_PIN    66
#define EXMC_D9_PIN     65
#define EXMC_D8_PIN     64
#define EXMC_D7_PIN     63
#define EXMC_D6_PIN     60
#define EXMC_D5_PIN     59
#define EXMC_D4_PIN     58   //PE7
#define EXMC_D3_PIN     115  //PD1
#define EXMC_D2_PIN     114  //PD0
#define EXMC_D1_PIN     86   //PD15
#define EXMC_D0_PIN     85   //PD14
#define LCD_POWR_PIN    3    //E4
#define SPI0_SCK_PIN    41   //A5
#define SPI0_MOSI_PIN   43   //A7
#define SPI0_MISO_PIN   42   //A6

/* end of definitions of EXMC pins */

void lcd_ctr(void)
{
    rt_pin_mode(LCD_POWR_PIN, PIN_MODE_INPUT_PULLUP);

    //rt_pin_mode(SPI0_MISO_PIN, PIN_MODE_OUTPUT);
    //rt_pin_mode(SPI0_MOSI_PIN, PIN_MODE_OUTPUT);
    //rt_pin_mode(SPI0_SCK_PIN, PIN_MODE_OUTPUT);

    //rt_pin_write(SPI0_MISO_PIN, PIN_LOW);
   // rt_pin_write(SPI0_MOSI_PIN, PIN_LOW);
    //rt_pin_write(SPI0_SCK_PIN,  PIN_LOW);

    while(1)
    {
        rt_pin_write(LCD_POWR_PIN,!rt_pin_read(LCD_POWR_PIN));   // toggle
        rt_thread_mdelay(3000);
    }
}

//INIT_APP_EXPORT(lcd_ctr);





