/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-06-01     Keris       the first version
 *
 *   **���ڼ�ⰴ��״̬
 *
 */

#include <mypins.h>
#include <drivers/pin.h>



/* �жϻص�����,����ƵĿ��� */
static void backlight_toggle(void)
{
    /* backlight toggle */
    rt_kprintf("Light on backlight!\n");
}


static void func_sel_key(void)
{
    rt_kprintf("Select functions!\n");
}

static void menu_key(void)
{
    rt_kprintf("Menu!\n");
}

void monitor_keys(){
    /* ��������Ϊ����ģʽ */
    rt_pin_mode(KEY_SIG_PIN,PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(KEY_DIRECTION_PIN,PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(KEY_BACKLIGHT_PIN,PIN_MODE_INPUT_PULLUP);

    /* ���жϣ�������ģʽ���ص�������Ϊbacklight_toggle */
    rt_pin_attach_irq(KEY_SIG_PIN, PIN_IRQ_MODE_FALLING, menu_key, RT_NULL);
    rt_pin_attach_irq(KEY_DIRECTION_PIN, PIN_IRQ_MODE_FALLING, func_sel_key, RT_NULL);
    rt_pin_attach_irq(KEY_BACKLIGHT_PIN, PIN_IRQ_MODE_FALLING, backlight_toggle, RT_NULL);

    /* ʹ��KEY_BACKLIGHT_PIN�ж� */
    rt_pin_irq_enable(KEY_SIG_PIN, PIN_IRQ_ENABLE);
    rt_pin_irq_enable(KEY_DIRECTION_PIN, PIN_IRQ_ENABLE);
    rt_pin_irq_enable(KEY_BACKLIGHT_PIN, PIN_IRQ_ENABLE);

}

INIT_APP_EXPORT(monitor_keys);
