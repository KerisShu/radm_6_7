/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-05-26     shangwang7       the first version
 */
#include <drivers/pin.h>
#include <led.h>


#define KEY0_PIN_NUM            15    /* PC13 */
#define BEEP_PIN_NUM            13


static void pin_beep_sample(void)
{
    rt_pin_mode(BEEP_PIN_NUM, PIN_MODE_OUTPUT);
    rt_pin_write(BEEP_PIN_NUM, PIN_LOW);

    /* ����0����Ϊ����ģʽ */
    rt_pin_mode(KEY0_PIN_NUM, PIN_MODE_INPUT_PULLUP);

    /* ���жϣ�������ģʽ���ص�������Ϊb */
    rt_pin_attach_irq(KEY0_PIN_NUM, PIN_IRQ_MODE_FALLING, led_toggle, RT_NULL);

    /* ʹ���ж� */
    rt_pin_irq_enable(KEY0_PIN_NUM, PIN_IRQ_ENABLE);


}

//INIT_ENV_EXPORT(pin_beep_sample);
