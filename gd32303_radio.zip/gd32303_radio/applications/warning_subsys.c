/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-05-25     Keris      the first version
 */
#include "base_con.h"
#include <rtdevice.h>
#include <board.h>
#include <mypins.h>

static DATATYPE thresh_val = 60; // ������ֵ
static DATATYPE current_val= 0;  // ��ǰ����ֵ

/* ������ƿ� */
extern struct rt_mailbox val_info_mb;
/* end of mailbox control */

/* ���ڷ��ʼ����ڴ�� */
extern char val_info_mb_pool[POOLSIZE];

/* led warning thread entry function */
static void warning_func(void *param)
{
    rt_pin_mode(LED_WARNING_PIN,PIN_MODE_OUTPUT);
    rt_pin_mode(BUZZER_PIN,PIN_MODE_OUTPUT);
    int* cval_rx;
    while(1)
    {
           // �ﵽ��ֵ�󱨾�
           if (current_val >= thresh_val )
           {
              rt_pin_write(BUZZER_PIN, PIN_HIGH);
              rt_pin_write(LED_WARNING_PIN, PIN_HIGH);
              rt_thread_mdelay(125);

              rt_pin_write(BUZZER_PIN, PIN_LOW);
              rt_pin_write(LED_WARNING_PIN, PIN_LOW);
              rt_thread_mdelay(125);
            }
           else // ������ֵ�����߳̾ͼ������շ���ֵ
           {
               rt_kprintf("warning thread: try to recv a mail from radiometer thread.\n");
               if (rt_mb_recv(&val_info_mb, (rt_uint32_t *)&cval_rx, RT_WAITING_FOREVER) == RT_EOK)
               {
                   rt_kprintf("warning thread: get a mail from radiometer thread, the content:%d.\n",*cval_rx);
                   rt_kprintf("\n");

                   current_val = *cval_rx;
               }
           }
    }
}

/* warning thread */
int warning_thread(void) // �������������������߳�
{
    rt_thread_t warning = RT_NULL;

    /* warning thread */
    warning = rt_thread_create("warning_thread",
                            warning_func, RT_NULL,
                            THREAD_STACK_SIZE,
                            WARNING_THREAD_PRIORITY, WARNING_TIMESLICE);

    if (warning != RT_NULL)
        rt_thread_startup(warning);
    else
        rt_kprintf("Failed: warning start ");

    return 0;
}

INIT_APP_EXPORT(warning_thread);
