/*
 * File      : main.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006 - 2018, RT-Thread Development Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-05-11     Keris       first implementation
 */
/* files of DFS */
#include <board.h>
#include "spi_flash.h"
#include "spi_flash_sfud.h"
/* end of files of DFS */

#include "led.h"
#include <rtdevice.h>
#include <rtthread.h>
#include <gd32f30x_rtc.h>// gd32f30x_rtc���ּĴ�������
#include "gd32f30x.h"
#include <drivers/spi.h>
#include "base_con.h"

int main(void)
{
    /* password */

    //finsh_set_password("12345678");

    /* end of password */

    led_init();
    led_on();

    //  initial mailbox
    mailbox_init();

    //rt_pin_write(TEMP_PIN, PIN_LOW);

    /* register test to figure out the principle of register */

    /*rt_kprintf("APB1_BUS_BASE : 0x%x\n",APB1_BUS_BASE  );
    rt_kprintf("SPI_BASE: 0x%x\n",SPI_BASE  );
    rt_kprintf("SPI0: 0x%x\n",SPI0  );

    reg_value = SPI_CTL0(SPI1);
    rt_kprintf("reg_value value: 0x%8x\n",reg_value  );

    rt_kprintf("SPI_CTL0_CKPH   address:0x%x\n",SPI_CTL0_CKPH  );
    rt_kprintf("SPI_CTL0_CKPH   value:0x%x\n",SPI_CTL0_CKPH  );*/
    /* end of register test */

    return RT_EOK;
}



